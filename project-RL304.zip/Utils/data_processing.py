from get_data import RequestAndSavedata
from Indicator_calc import calc

# Step 1
# RequestAndSavedata()

# Step 2
calc()